package Quiz2.Application;

public class Employee {

    private Integer id;

    private String name;

    private String position;

    private Double salary;


    public Employee() {
        id = -1;
        name = "";
        position = "";
        salary = 0.0D;

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }
}
